package ir.quizking.app
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp

class MainActivity : ComponentActivity() {
 override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); setContent { Screen() } }
}
@Composable fun Screen() {
 var name by remember { mutableStateOf("") }
 var phone by remember { mutableStateOf("") }
 var pass by remember { mutableStateOf("") }
 var invite by remember { mutableStateOf("") }
 var started by remember { mutableStateOf(false) }
 MaterialTheme {
  Surface(Modifier.fillMaxSize()) {
   if (!started) Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement=Arrangement.Center, horizontalAlignment=Alignment.CenterHorizontally) {
    Text("👑 QUIZ KING", style=MaterialTheme.typography.headlineLarge)
    Text("ثبت‌نام و ورود")
    OutlinedTextField(name,{name=it},label={Text("نام کاربری")},modifier=Modifier.fillMaxWidth())
    OutlinedTextField(phone,{phone=it},label={Text("شماره موبایل")},modifier=Modifier.fillMaxWidth())
    OutlinedTextField(pass,{pass=it},label={Text("رمز عبور")},visualTransformation=PasswordVisualTransformation(),modifier=Modifier.fillMaxWidth())
    OutlinedTextField(invite,{invite=it},label={Text("کد دعوت (اختیاری)")},modifier=Modifier.fillMaxWidth())
    Button(onClick={started=true},enabled=name.length>=3 && phone.isNotBlank() && pass.length>=8,modifier=Modifier.fillMaxWidth()) { Text("پیش‌نمایش ثبت‌نام") }
    Text("نمونه نمایشی؛ هنوز به سرور یا پیامک متصل نیست.")
   } else Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement=Arrangement.spacedBy(12.dp)) {
    Text("خوش آمدی، $name",style=MaterialTheme.typography.headlineMedium)
    Text("موجودی نمایشی: ${if(invite.isBlank()) 55 else 70} سکه")
    Text("گردونه هر ۲۴ ساعت: ۲ پوچ، ۲×۱۰، ۲×۱۵، ۱×۲۰ سکه")
    Text("کمک‌ها: ۵۰-۵۰ = ۱۰ | فرصت دوباره = ۱۵ | ۱۰ ثانیه اضافه = ۱۰ سکه")
    Text("مسابقه رایگان: ۱۵ سؤال، هر پاسخ صحیح ۱۰ امتیاز، ۱۰ ثانیه برای هر سؤال.")
    Button(onClick={started=false}) { Text("بازگشت") }
   }
  }
 }
}
