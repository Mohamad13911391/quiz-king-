package ir.quizking
import org.springframework.web.bind.annotation.*
import java.time.Instant
import java.util.concurrent.ConcurrentHashMap
import kotlin.random.Random

data class RegisterBody(val username: String, val phone: String, val password: String, val inviteCode: String? = null)
@RestController
@RequestMapping("/api")
class Api {
    private val spinAt = ConcurrentHashMap<String, Instant>()
    @GetMapping("/health") fun health() = mapOf("status" to "ok")
    @PostMapping("/auth/register")
    fun register(@RequestBody body: RegisterBody): Map<String, Any> {
        require(body.username.length >= 3 && body.password.length >= 8 && body.phone.isNotBlank())
        return mapOf("message" to "Starter endpoint only; connect database and OTP before production",
            "welcomeCoins" to 55, "inviteBonusCoins" to if (body.inviteCode.isNullOrBlank()) 0 else 15)
    }
    @PostMapping("/spin/{userId}")
    fun spin(@PathVariable userId: String): Map<String, Any> {
        val now = Instant.now()
        val last = spinAt[userId]
        require(last == null || !now.isBefore(last.plusSeconds(86400))) { "Try again after 24 hours" }
        spinAt[userId] = now
        val reward = listOf(0, 0, 10, 10, 15, 15, 20).random()
        return mapOf("reward" to reward, "nextSpinAt" to now.plusSeconds(86400).toString())
    }
}
